package acervo;

import java.time.LocalDate;

public class Emprestimo extends Livro{
     
    private int id;
    private int idUsuario;
    private int idLivro;
    private LocalDate dataEmprestimo;
    private LocalDate dataDevolucao;
    private boolean devolvido;

    public Emprestimo(){
    }
    
    public Emprestimo(int id, LocalDate dataEmprestimo, LocalDate dataDevolucao, boolean devolvido, int idLivro, String titulo, String autor, String edicao, String editora, String cidade, int anopublicacao, int idUsuario, String nome, String email, String senha){
        super(idLivro, titulo, autor, edicao, editora, cidade, anopublicacao, idUsuario, nome, email, senha);
        this.id = id;
        this.idUsuario = idUsuario;
        this.idLivro = idLivro;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.devolvido = devolvido;
    }
    
    public Emprestimo(int id, int idUsuario, int idLivro, LocalDate dataEmprestimo, LocalDate dataDevolucao, boolean devolvido) {
        super(idLivro, idUsuario);
        this.id = id;
        this.idUsuario = idUsuario;
        this.idLivro = idLivro;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolucao = dataDevolucao;
        this.devolvido = devolvido;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

   
    
    public int getIdUsuario() {
        return super.getIdUsuario();
    }
    
    
    public void setIdUsuario(int idUsuario) {
        super.setIdUsuario(idUsuario);
    }

    
    public int getIdLivro() {
        return super.getIdLivro();
    }
    
    public void setIdLivro(int idLivro) {
        super.setIdLivro(idLivro);
    }

    public LocalDate getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(int i, int j, int k) {
        LocalDate dataE;
        dataE = LocalDate.of(i,j,k);
        this.dataEmprestimo = dataE;
    }

    public LocalDate getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(int i, int j, int k) {
        LocalDate dataD;
        dataD = LocalDate.of(i, j, k);
        this.dataDevolucao = dataD;
    }

    public boolean isDevolvido() {
        return devolvido;
    }

    public void setDevolvido(boolean devolvido) {
        this.devolvido = devolvido;
    }

    @Override
    public String toString() {
        return  "ID do emprestimo: " + getId() + "\n" +
                "ID do usuário: " + super.getIdUsuario() + "\n" +
                "ID do livro: " + super.getIdLivro() + "\n" +
                "Data do emprestimo: " + getDataEmprestimo() + "\n" +
                "Data da devolução: " + getDataDevolucao() + "\n" +
                "O livro foi devolvido: " +isDevolvido() + "\n";
    }
}
