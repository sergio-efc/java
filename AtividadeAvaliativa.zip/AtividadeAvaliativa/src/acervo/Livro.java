package acervo;

public class Livro extends Usuario{
    
    private int idLivro;
    private String titulo;
    private String autor;
    private String edicao;
    private String editora;
    private String cidade;
    private int anopublicacao;
    
    public Livro(){
    }
    
    public Livro(int idLivro, int idUsuario){
        super(idUsuario);
        this.idLivro = idLivro;
    }
    
    public Livro(int idLivro, String titulo, String autor, String edicao, String editora, String cidade, int anopublicacao) {
        this.idLivro = idLivro;
        this.titulo = titulo;
        this.autor = autor;
        this.edicao = edicao;
        this.editora = editora;
        this.cidade = cidade;
        this.anopublicacao = anopublicacao;
    }

    public Livro(int idLivro, String titulo, String autor, String edicao, String editora, String cidade, int anopublicacao, int idUsuario, String nome, String email, String senha) {
        super(idUsuario, nome, email, senha);
        this.idLivro = idLivro;
        this.titulo = titulo;
        this.autor = autor;
        this.edicao = edicao;
        this.editora = editora;
        this.cidade = cidade;
        this.anopublicacao = anopublicacao;
    }
    
    public int getIdLivro() {
        return idLivro;
    }

    public void setIdLivro(int idLivro) {
        this.idLivro = idLivro;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEdicao() {
        return edicao;
    }

    public void setEdicao(String edicao) {
        this.edicao = edicao;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public int getAnopublicacao() {
        return anopublicacao;
    }

    public void setAnopublicacao(int anopublicacao) {
        this.anopublicacao = anopublicacao;
    }

    @Override
    public String toString() {
        return  "ID do livro: " + getIdLivro() + "\n" +
                "Título: " + getTitulo() + "\n" +
                "Autor: " + getAutor() + "\n" +
                "Edição: " + getEdicao() + "\n" +
                "Editora: " + getEditora() + "\n" +
                "Cidade: " + getCidade() + "\n" +
                "Ano de publicação: " + getAnopublicacao() + "\n";
    }
}
