package acervo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class UsuarioTeste {
    public static void main(String[] args) {
        
        ArrayList<Usuario> usuarios = new ArrayList<>();
        ArrayList<Livro> livros = new ArrayList<>();
        ArrayList<Emprestimo> emprestimos = new ArrayList<>();
        
        usuarios.add(new Usuario(1, "sérgio", "teste@outlook.com", "123"));
        usuarios.add(new Usuario(2, "lucas", "teste2@outlook.com", "123"));
        usuarios.add(new Usuario(3, "jorge", "teste3@outlook.com", "123"));
        
        livros.add(new Livro(10, "o conto de aia", "Margaret Atwood", "primeira", "rocco", "nepal", 1985));
        livros.add(new Livro(20, "A Garota do Lago", "Charlie Donlea", "primeira", "faro editorial", "santos", 2016));
        
        emprestimos.add(new Emprestimo(100, 1, 10, LocalDate.of(2020, 5, 11), LocalDate.of(2020, 5, 13), true));
        emprestimos.add(new Emprestimo(200, 3, 20, LocalDate.of(2020, 5, 12), LocalDate.of(2020, 5, 18), false));
        
        int alt;
        
	do {
		System.out.println("\n                  =============================");
		System.out.println("                  |     1 - Procurar nome     |");
		System.out.println("                  |     2 - Procurar livro    |");
		System.out.println("                  |     3 - listar emprestimo |");
		System.out.println("                  |     4 - listar tudo       |");
		System.out.println("                  |     0 - Sair              |");
		System.out.println("                  =============================\n");
                
                Scanner scan = new Scanner(System.in);
                System.out.println("Alternativa: ");
                alt = scan.nextInt();
		System.out.print("\n");
                
		switch (alt) {
		case 1:
                        Scanner scan2 = new Scanner(System.in);
                        System.out.println("Qual o nome que deseja procurar: ");
                        String username = scan2.next();
        
                        for(int i=0; i < usuarios.size(); i++){
                            if(usuarios.get(i).getNome().contains(username)){
                                System.out.println("O usuário foi encontrado");
                                System.out.println(usuarios.get(i));
                                System.out.println("\n\n");
                            }  
                        }
			break;
		case 2:
			System.out.println("Qual o ID do livro que deseja procurar: ");
                        Scanner scan3 = new Scanner(System.in);
                        int IDbook = scan3.nextInt();
        
                        for(int i=0; i < livros.size(); i++){
                            if(livros.get(i).getIdLivro() == (IDbook)){
                                System.out.println("O livro foi encontrado");
                                System.out.println(livros.get(i));
                                System.out.println("\n\n");
                            }  
                        }
			break;
                   
		case 3:
			for(int i=0; i < emprestimos.size(); i++){
                            if(emprestimos.get(i).isDevolvido() == true){
                                System.out.println("O(s) livro(s) foi(foram) devolvido(s)");
                                System.out.println(emprestimos.get(i));
                                System.out.println("\n\n");
                            }
                            else{
                                System.out.println("O(s) livro(s) não foi(foram) devolvido(s)");
                                System.out.println(emprestimos.get(i));
                                System.out.println("\n\n");
                            }
                        }
			break;
                case 4:
                        for(Usuario f: usuarios){
                            System.out.println(f);
                        }
                        for(Livro f: livros){
                            System.out.println(f);
                        }
                        for(Emprestimo f: emprestimos){
                            System.out.println(f);
                        }
                        break;
		case 0:
			break;
		default:
			System.out.println("Opção Inválida!");
			break;
		}
	} while (alt != 0);
    }  
}